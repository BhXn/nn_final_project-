## 参考配置
- 系统：Ubuntu 20.04
- CUDA：12.4
- gcc：9.5
- cmake：4.0.1